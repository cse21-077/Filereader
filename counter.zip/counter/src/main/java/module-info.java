module com.example.robiee {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.calvincounter to javafx.fxml;
    exports com.example.calvincounter;
}