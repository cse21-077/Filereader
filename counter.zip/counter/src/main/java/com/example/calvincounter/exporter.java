package com.example.calvincounter;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

import static com.example.calvincounter.home.Words;



public class exporter {

    @FXML
    private TextArea textArea;

    public void initialize() {
        Scanner scanner = new Scanner(String.valueOf(Words));
        while (scanner.hasNextLine()) {
            textArea.appendText(scanner.nextLine() + "\n");

        }

    }

    @FXML
    void savebtn(MouseEvent event) throws FileNotFoundException {
        FileChooser fc = new FileChooser();
        java.io.File picked = fc.showSaveDialog(new Stage( ));
        if (picked != null){
            save(picked, textArea.getText());


        }


    }





    private void save(java.io.File picked, String text) throws FileNotFoundException {
        PrintWriter printw = new PrintWriter(picked);
        printw.write(text);
        printw.close();

    }
    }
