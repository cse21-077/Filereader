package com.example.calvincounter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class home {
    @FXML
    private TextField timecount;

    @FXML
    private TextField wcount;

    @FXML
    private BorderPane borderpane;

    public static ArrayList<String> Words = new ArrayList<>();




    @FXML
    File readfile(ActionEvent event) throws IOException {
        File fpath = new File("100.txt");


        File push = new File(fpath.getAbsolutePath());
        int countwords = count(push);
        RandomWord(String.valueOf(push));

        wcount.setText(wcount.getText() + countwords);

        wcount.setStyle("-fx-text-inner-color: grey");// to change text-field color


        return push ;


    }

    public int count(File obj) {//Method to count words
        long start = System.currentTimeMillis();
        int countofwords = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(obj));

            String liner = null;
            String boyzen[] = null;
            while ((liner = br.readLine()) != null) {
                boyzen = liner.split(" ");
                countofwords = countofwords + boyzen.length;
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        long end = System.currentTimeMillis();
        long time = end - start;
        System.out.println(time);
        timecount.setText(timecount.getText() + time);
        timecount.setStyle("-fx-text-inner-color: grey");// to change text-field color
        return countofwords;


    }

    public ArrayList RandomWord(String fpath ) throws IOException {//Method Adding Words to An Array

        try (BufferedReader reader = new BufferedReader(new FileReader(fpath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] wordline = line.split("\\s+");

                if (Words.size() < 20) {
                    for (String word : wordline) {

                        Words.add(word);
                        System.out.println(Words);
                    }

                }

            }
            return Words;
        }


    }

    @FXML
    void file(ActionEvent event) throws IOException {
        AnchorPane view = FXMLLoader.load(getClass().getResource("exporter.fxml"));
        borderpane.setCenter(view);


    }


    @FXML
    void homebtn(ActionEvent event) throws IOException {
        AnchorPane view = FXMLLoader.load(getClass().getResource("count.fxml"));
        borderpane.setCenter(view);

    }



    @FXML
    void searchbtn(ActionEvent event) throws IOException {
        AnchorPane view = FXMLLoader.load(getClass().getResource("search.fxml"));
        borderpane.setCenter(view);



    }


    }






