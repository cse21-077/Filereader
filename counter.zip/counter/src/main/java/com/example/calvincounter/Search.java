package com.example.calvincounter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import static com.example.calvincounter.home.Words;
public class Search implements Initializable {

    @FXML
    private ListView<String> listArea;

    @FXML
    private TextField searchArea;

    @FXML
    private Button search;

    public  void  initialize(URL url, ResourceBundle resourceBundle){
        listArea.getItems().addAll(Words);
    }


    @FXML
    void search(ActionEvent event) {
        listArea.getItems().clear();
        listArea.getItems().addAll(searchList(searchArea.getText(), Words));

    }



    public List<String> searchList(String searchWords, List<String> listOfStrings)  {
        List<String> searchWordsArray = Arrays.asList(searchWords.trim().split("\\s+ "));

        return listOfStrings.stream().filter(input ->{
            return searchWordsArray.stream().allMatch(word ->
                    input.toLowerCase().contains(word.toLowerCase()));
        }).collect(Collectors.toList());




    }



}
